"""Record C4 inputs from retained staging code; replay candidate offline.

This companion never overwrites the original M0b bundle. No generation or
answer-quality evaluation is performed. Provider calls occur only in record.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
import os
import socket
from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from unittest.mock import patch
from uuid import UUID

ROOT = Path(__file__).resolve().parents[1]
HEAD = "39d78476b243e1a7b8dd268cb5362516198368cb"
RETAINED = "3bd4b912b0ba731a997ddb5257fc0c10d39b62e4"


def plain(value):
    if is_dataclass(value):
        return {f.name: plain(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, Mapping):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(v) for v in value]
    if isinstance(value, (date, datetime, UUID)):
        return str(value)
    return value


def dump(path, value):
    path.write_text(json.dumps(plain(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def configure_record():
    from dotenv import dotenv_values
    import psycopg
    from psycopg.conninfo import conninfo_to_dict, make_conninfo

    values = dotenv_values("/Users/dasco/dev/clients/dinuum/assistant-rh/.env")
    staging = values.get("SCW_POSTGRES_DSN_STAGING")
    assert staging, "explicit staging DSN missing"
    params = conninfo_to_dict(staging)
    prod = conninfo_to_dict(values.get("SCW_POSTGRES_DSN_PROD") or "")
    assert (params.get("host"), params.get("port"), params.get("dbname")) != (
        prod.get("host"), prod.get("port"), prod.get("dbname")
    ), "staging and production target identities must differ"
    for key in list(os.environ):
        if key.startswith("PG"):
            del os.environ[key]
    for key in ("ALBERT_API_KEY", "ALBERT_BASE_URL", "SCALEWAY_API_KEY", "SCALEWAY_BASE_URL"):
        if values.get(key):
            os.environ[key] = values[key]
    dsn = make_conninfo(staging, sslmode="require", connect_timeout="10",
                        options="-c default_transaction_read_only=on -c statement_timeout=30000 -c lock_timeout=3000")
    os.environ.update(SCW_POSTGRES_DSN=dsn, APP_DB_TARGET="scaleway", APP_SCALEWAY_ENV="staging", APP_ENV="staging",
                      PYTHON_DOTENV_DISABLED="1", OTEL_SDK_DISABLED="true")
    with psycopg.connect(dsn) as conn:
        row = conn.execute("SELECT current_database(), current_user, current_setting('transaction_read_only'), version()").fetchone()
        assert row[2] == "on"
        counts = conn.execute("SELECT (SELECT count(*) FROM rag_documents), (SELECT count(*) FROM rag_sections)").fetchone()
        assert min(counts) > 0, "not a populated staging corpus"
    return dsn, {"target": "explicit_staging", "read_only": True, "server_version": row[3],
                 "database_identity_sha256": hashlib.sha256((params.get("host", "") + row[0]).encode()).hexdigest(),
                 "document_count": counts[0], "section_count": counts[1]}


def record(output):
    output.mkdir(parents=True, exist_ok=False)
    os.chmod(output, 0o700)
    logging.basicConfig(filename=output / "private-record.log", level=logging.WARNING)
    dsn, identity = configure_record()
    import psycopg
    from assistant_rh_rag_pipeline.admin import RuntimeRAGConfig, runtime_config_to_rag_config
    from assistant_rh_rag_pipeline.pipeline import Pipeline, _RunState
    from assistant_rh_rag_pipeline.ministry_scope import build_retrieval_scope, resolve_ministry
    from assistant_rh_rag_pipeline.reranker import AlbertReranker

    with psycopg.connect(dsn) as conn:
        runtime_config = conn.execute("SELECT config FROM rag_config WHERE id=1").fetchone()[0]
    assert isinstance(runtime_config, dict) and runtime_config
    config = runtime_config_to_rag_config(RuntimeRAGConfig.from_dict(runtime_config))
    dump(output / "config.json", config.to_dict())
    dump(output / "database.json", identity)
    active_capture = []
    real_connect = psycopg.connect

    class RecordingCursor(psycopg.Cursor):
        def fetchall(self):
            rows = super().fetchall()
            if active_capture:
                active_capture[-1].append(plain(rows))
            return rows

        def fetchone(self):
            row = super().fetchone()
            if active_capture:
                active_capture[-1].append(plain(row))
            return row

    def connect(*args, **kwargs):
        # Override session options even for helpers opening separate connections.
        kwargs.update(cursor_factory=RecordingCursor, connect_timeout=10,
                      options="-c default_transaction_read_only=on -c statement_timeout=30000 -c lock_timeout=3000")
        return real_connect(*args, **kwargs)

    fixtures = [json.loads(line) for line in (ROOT / "tests/conformance/queries.m0-api-parity.jsonl").read_text().splitlines()]
    reports = []
    with patch.object(psycopg, "connect", connect):
        for fixture in fixtures:
            print("recording " + fixture["id"], flush=True)
            pipe = Pipeline(config, dsn=dsn)
            recorded = {"fixture": fixture, "aggregation_calls": [], "context_calls": []}
            current_agg = []

            def wrap_read(original, bucket, arg_name):
                def call(arg):
                    event = {arg_name: plain(arg), "sql_results": []}
                    bucket.append(event)
                    active_capture.append(event["sql_results"])
                    try:
                        result = original(arg)
                        event["result"] = plain(result)
                        return result
                    finally:
                        active_capture.pop()
                return call

            agg = pipe._aggregator
            builder = pipe._context_builder
            original_aggregate = agg.aggregate_with_diagnostics
            original_build = builder.build
            original_sections = agg._fetch_sections
            original_documents = builder._load_full_document
            original_refs = builder._resolve_cids

            def aggregate(chunks, query=None):
                entry = {"chunks": plain(chunks), "query": query, "section_reads": [], "rerank": None}
                recorded["aggregation_calls"].append(entry)
                current_agg.append(entry)
                agg._fetch_sections = wrap_read(original_sections, entry["section_reads"], "ids")
                try:
                    result = original_aggregate(chunks, query)
                    entry["expected"] = plain(result)
                    return result
                finally:
                    current_agg.pop()

            real_reranker = AlbertReranker()
            real_rank = real_reranker.rerank
            real_post = real_reranker._post

            def post(*args, **kwargs):
                response = real_post(*args, **kwargs)
                event = {"request": plain(kwargs.get("json")), "status": response.status_code}
                try:
                    event["body"] = response.json()
                except ValueError:
                    event["body"] = None
                current_agg[-1]["rerank"]["http"].append(event)
                return response

            def rank(query, texts, top_k=None):
                event = {"query": query, "texts": list(texts), "top_k": top_k, "http": []}
                current_agg[-1]["rerank"] = event
                try:
                    result = real_rank(query, texts, top_k)
                    event["result"] = plain(result)
                    return result
                except Exception as exc:
                    event["error_type"] = type(exc).__name__
                    raise

            real_reranker._post = post
            real_reranker.rerank = rank
            agg._reranker = real_reranker
            agg.aggregate_with_diagnostics = aggregate

            def build(sections):
                entry = {"sections": plain(sections), "document_reads": [], "reference_reads": []}
                recorded["context_calls"].append(entry)
                builder._load_full_document = wrap_read(original_documents, entry["document_reads"], "id")
                builder._resolve_cids = wrap_read(original_refs, entry["reference_reads"], "numbers")
                result = original_build(sections)
                entry.update(expected_items=plain(result), expected_refs=plain(builder.last_resolved_refs),
                             expected_prompt=builder.format_for_prompt(result))
                return result

            builder.build = build
            scope = build_retrieval_scope(fixture["ministry"]) if fixture.get("ministry") else None
            qr = pipe.process_query(fixture["query"], fixture.get("conversation_history"), retrieval_scope=scope)
            recorded["query_result"] = plain(qr)
            if qr.should_proceed:
                state = _RunState()
                items = pipe._retrieve_and_build(qr, state, retrieval_scope=scope, ministry=resolve_ministry(scope))
                recorded["final_context"] = plain(items)
                recorded["selector_trace"] = [plain(e) for e in state.trace_events if e.get("stage") == "context-selector"]
                recorded["final_prompt"] = builder.format_for_prompt(items)
            name = fixture["id"] + ".json"
            dump(output / name, recorded)
            reports.append({"id": fixture["id"], "file": name, "sha256": digest(output / name),
                            "aggregation_calls": len(recorded["aggregation_calls"]), "context_calls": len(recorded["context_calls"]),
                            "should_proceed": bool(qr.should_proceed)})
            print("captured " + fixture["id"], flush=True)
    sources = {}
    for base in (ROOT / "retained-staging/packages/rag-pipeline/src", ROOT / "apps/api/src/assistant_rh_api/core"):
        for path in sorted(base.rglob("*.py")):
            sources[str(path.relative_to(ROOT))] = digest(path)
    dump(output / "manifest.json", {"schema": "c4-companion-v1", "candidate_sha": HEAD, "retained_sha": RETAINED,
                                   "created_at": datetime.now(timezone.utc).isoformat(), "source": "staging_read_only",
                                   "generation_executed": False, "scope": "C4 aggregation and context; upstream execution supplies inputs",
                                   "config_sha256": digest(output / "config.json"), "fixtures": reports, "source_hashes": sources})


def assert_equal(actual, expected, label):
    if plain(actual) != expected:
        raise AssertionError(label)


async def replay(output):
    from assistant_rh_api.core.models.context import AggregatedSection
    from assistant_rh_api.core.models.retrieval import RetrievedChunk, Document, Section, LegalReference
    from assistant_rh_api.core.models.inference import Reranking, RankedDocument
    from assistant_rh_api.core.models.rag_configuration import SectionAggregationConfig, ContextBuildConfig, ContextMode
    from assistant_rh_api.core.pipeline.steps.aggregation import SectionAggregator
    from assistant_rh_api.core.pipeline.steps.context_builder import ContextBuilder
    from assistant_rh_api.core.pipeline.steps.context_formatting import format_for_prompt

    manifest = json.loads((output / "manifest.json").read_text())
    assert digest(output / "config.json") == manifest["config_sha256"]
    for name, sha in manifest["source_hashes"].items():
        assert digest(ROOT / name) == sha, "source revision changed"
    config = json.loads((output / "config.json").read_text())
    agg_config = SectionAggregationConfig(**config["aggregation"])
    ctx_config = ContextBuildConfig(**{**config["context"], "context_mode": ContextMode(config["context"]["context_mode"])})

    class Store:
        def __init__(self, entry):
            self.entry = entry
            self.read_index = 0

        async def sections(self, ids):
            read, = self.entry["section_reads"]
            assert set(ids) == set(read["ids"])
            rows = read["result"]
            assert rows is not None
            result = []
            for sid, row in rows.items():
                doc = Document(str(row["doc_id"]), row["doc_short_id"], row["doc_title"], row["doc_url"], row["doc_publisher"],
                               "", row["doc_token_count"], row["doc_date"]) if row.get("doc_id") else None
                result.append(Section(sid, row["doc_id"], row["heading"] or "", row["heading_path"],
                                      row["section_markdown"], row["references_juridiques"], doc))
            return tuple(result)

        async def documents(self, ids):
            read = self.entry["document_reads"][self.read_index]
            self.read_index += 1
            assert tuple(ids) == (read["id"],), "document read order differs"
            row = read["result"]
            if row is None:
                return ()
            return (Document(str(row["doc_id"]), None, row["title"], row["source_url"], row["publisher"],
                             row["doc_markdown"] or "", row["token_count"]),)

        async def references(self, numbers):
            read, = self.entry["reference_reads"]
            assert set(numbers) == set(read["numbers"])
            raw, = read["sql_results"]
            # B2 adapter orders distinct reference rows lexicographically.
            rows = sorted(set((r["number"], r["cid"] or "", r["url"] or "", r["full_title"] or "") for r in raw))
            return tuple(LegalReference(*r) for r in rows)

    class Ranker:
        def __init__(self, entry):
            self.entry = entry

        async def rerank(self, query, documents, *, top_k=None):
            entry = self.entry
            assert entry and "error_type" not in entry, "provider failure requires separate replay contract"
            assert (query, list(documents), top_k) == (entry["query"], entry["texts"], entry["top_k"])
            return Reranking(tuple(RankedDocument(*row) for row in entry["result"]), ())

    def section(row):
        return AggregatedSection(**{**row, "chunks": tuple(RetrievedChunk(**c) for c in row["chunks"])})

    results = []
    # Replay is forbidden from opening network sockets, including database and providers.
    def deny(*args, **kwargs):
        raise AssertionError("offline replay attempted network I/O")

    with patch.object(socket.socket, "connect", deny), patch.object(socket, "create_connection", deny):
        for fixture in manifest["fixtures"]:
            assert digest(output / fixture["file"]) == fixture["sha256"]
            record = json.loads((output / fixture["file"]).read_text())
            failures = []
            for index, entry in enumerate(record["aggregation_calls"]):
                result = await SectionAggregator(agg_config, Store(entry), Ranker(entry["rerank"])).aggregate_with_diagnostics(
                    tuple(RetrievedChunk(**c) for c in entry["chunks"]), entry["query"])
                checks = {"sections": (plain(result.sections), entry["expected"]["sections"])}
                for key, expected in entry["expected"]["diagnostics"].items():
                    checks["diagnostics." + key] = (plain(getattr(result.diagnostics, key)), expected)
                for key, (actual, expected) in checks.items():
                    if actual != expected:
                        failures.append(f"aggregation[{index}].{key}")
                        dump(output / (fixture["id"] + ".aggregation-diff.json"), {"actual": plain(result), "expected": entry["expected"]})
            for index, entry in enumerate(record["context_calls"]):
                store = Store(entry)
                result = await ContextBuilder(ctx_config, store).build(tuple(section(row) for row in entry["sections"]))
                checks = {"items": (plain(result.items), entry["expected_items"]),
                          "refs": (plain(result.resolved_refs), entry["expected_refs"]),
                          "prompt": (format_for_prompt(result.items), entry["expected_prompt"])}
                assert store.read_index == len(entry["document_reads"]), "unused document recording"
                for key, (actual, expected) in checks.items():
                    if actual != expected:
                        failures.append(f"context[{index}].{key}")
                        dump(output / (fixture["id"] + ".context-diff.json"), {"actual": plain(result), "expected": entry})
            results.append({"id": fixture["id"], "aggregation_calls": len(record["aggregation_calls"]),
                            "context_calls": len(record["context_calls"]), "failures": failures,
                            "status": "passed" if not failures and record["aggregation_calls"] else "not_exercised" if not failures else "failed"})
    report = {"candidate_sha": HEAD, "retained_sha": RETAINED, "offline_network_denied": True,
              "scope": "C4 only; no C2/C3/C5/generation parity claim", "fixtures": results,
              "exact_comparison": not any(r["failures"] for r in results)}
    dump(output / "comparison.json", report)
    print(json.dumps(report, indent=2))
    assert report["exact_comparison"], "C4 parity differences found"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["record", "replay", "preflight"])
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.mode == "record":
        record(args.output)
    elif args.mode == "replay":
        asyncio.run(replay(args.output))
    else:
        _, info = configure_record()
        print(json.dumps(info))
