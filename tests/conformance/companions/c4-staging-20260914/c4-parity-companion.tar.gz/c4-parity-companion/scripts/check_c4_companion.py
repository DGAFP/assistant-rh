"""Negative controls for the recorded C4 comparison, with no network access."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = ROOT / "evidence-v2"
env = {**os.environ, "PYTHON_DOTENV_DISABLED": "1", "PYTHONPATH": str(ROOT / "apps/api/src")}
checks = []
for mutation in ("integrity", "section_score", "prompt"):
    with tempfile.TemporaryDirectory(prefix="c4-negative-") as directory:
        target = Path(directory)
        for source in ORIGINAL.glob("*.json"):
            shutil.copy2(source, target / source.name)
        fixture = target / "rag-acronym-contract.json"
        payload = json.loads(fixture.read_text())
        if mutation == "section_score":
            payload["aggregation_calls"][0]["expected"]["sections"][0]["score"] += 0.01
        else:
            payload["context_calls"][0]["expected_prompt"] += " changed"
        fixture.write_text(json.dumps(payload, ensure_ascii=False))
        if mutation != "integrity":
            # Recompute the fixture hash to prove the comparison itself detects
            # differences, independently of the manifest integrity check.
            manifest_path = target / "manifest.json"
            manifest = json.loads(manifest_path.read_text())
            for row in manifest["fixtures"]:
                if row["file"] == fixture.name:
                    row["sha256"] = hashlib.sha256(fixture.read_bytes()).hexdigest()
            manifest_path.write_text(json.dumps(manifest))
        result = subprocess.run([sys.executable, str(ROOT / "scripts/c4_companion.py"), "replay", str(target)],
                                env=env, text=True, capture_output=True)
        assert result.returncode != 0, f"undetected mutation: {mutation}"
        if mutation != "integrity":
            report = json.loads((target / "comparison.json").read_text())
            assert not report["exact_comparison"]
            failures = report["fixtures"][0]["failures"]
            assert ("aggregation[0].sections" if mutation == "section_score" else "context[0].prompt") in failures
        checks.append({"control": mutation, "detected": True})
print(json.dumps(checks, indent=2))
(ORIGINAL / "negative-controls.json").write_text(json.dumps(checks, indent=2) + "\n")
