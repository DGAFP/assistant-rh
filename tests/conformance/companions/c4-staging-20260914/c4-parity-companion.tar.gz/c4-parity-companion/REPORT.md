# Preuve de parité C4 — PR #558

**Résultat : comparaison exacte réussie sur les quatre scénarios RAG enregistrés le 14 septembre 2026.**

Le candidat est le commit `39d78476b243e1a7b8dd268cb5362516198368cb` de la PR #558.
Le runtime de référence est le package conservé à la révision de la branche staging
`3bd4b912b0ba731a997ddb5257fc0c10d39b62e4`, exécuté localement sur le corpus staging.
Ce rapport ne prétend pas avoir vérifié la révision de l'image effectivement déployée.
Les modules historiques d'agrégation et de construction du contexte sont identiques
entre cette référence et le package conservé dans le commit candidat.

## Méthode

1. Copie isolée du candidat et du package de référence ; aucune modification du worktree de revue.
2. Identité staging vérifiée avec un DSN explicitement nommé staging, distinct de production.
   Connexions TLS, sessions forcées en lecture seule, délais de connexion et de requête bornés.
3. Exécution des sept questions publiques du panel M0b par le processeur de requête et
   l'enchaînement historique retrieval → agrégation → selector → contexte.
   Aucune génération de réponse finale, écriture distante ou publication.
4. Capture des entrées C4 avant leur traitement : chunks complets, métadonnées et scores
   non arrondis, lectures sections/documents, requêtes et réponses HTTP du reranker,
   résultat brut de ce dernier, sections reçues par le builder et configuration effective.
   Les sorties attendues sont enregistrées séparément après exécution du code historique.
5. Replay du core API avec des ports alimentés exclusivement par ces entrées. Les connexions
   réseau sont interdites par le runner de replay. Les empreintes des sources et fixtures sont vérifiées.
6. Comparaison exacte des sections et de leurs chunks, scores, ordre, diagnostics historiques,
   context items, métadonnées, références résolues et chaîne complète du contexte formaté.

Le selector reste hors du périmètre C4 : sa sortie enregistrée constitue l'entrée du builder.
Ce n'est pas une preuve de parité de C2, C3, C5, de la génération ou du transport HTTP.

## Résultats

| Scénario | Chunks entrants | Sections après reranking | Éléments de contexte | Documents entiers | Comparaison C4 |
|---|---:|---:|---:|---:|---|
| CDD / acronyme | 133 | 20 | 1 | 1 | Exacte |
| Subrogation / recherche juridique | 140 | 20 | 1 | 0 | Exacte |
| Renouvellement / historique de conversation | 131 | 20 | 2 | 2 | Exacte |
| Congé de mobilité / ministère MSO | 137 | 20 | 2 | 1 | Exacte |

Total : **541 chunks entrants, 80 sections après reranking, 6 éléments finaux dont 4 documents entiers**.
Chaque scénario RAG a effectué un appel reranker de 40 candidats, avec réponse HTTP 200.
Aucun avertissement ni erreur dans le journal d'enregistrement.

Les trois scénarios de court-circuit (salutation, demande de document, hors sujet) n'atteignent
pas C4 : ils sont marqués `not_exercised`, et ne sont pas comptés comme trois comparaisons réussies.

La configuration enregistrée utilise le mode wide, un budget principal de 12 000 tokens,
40 candidats au reranker et un top-k de sortie de 20. Les captures incluent des lectures
de sections et de documents entiers, mais **aucune résolution de références ni triangulation
n'a été sollicitée par ces quatre exécutions**. Ces branches restent étayées par les tests
synthétiques ; cette capture ne les certifie pas sur staging.

## Contrôles complémentaires

- Cinq comparaisons SQL synthétiques rejouées sur PostgreSQL 17.11 local : **5 passent**.
- Revue préalable du même commit : **367 tests passent**, Ruff et **3 contrats d'import** passent.
- Contrôles négatifs du runner : altération d'un fichier détectée ; modification d'un score
  et modification du prompt détectées même après recalcul de l'empreinte de la fixture.
- Bundle historique inchangé : **7 fixtures / 56 artefacts**, intégrité confirmée.
  Son auto-check historique conserve `exact_comparison: null`.
- Ce complément a son propre rapport avec **`exact_comparison: true`** sur C4.

## Portée de la preuve

La preuve demandée est obtenue : sur les cas RAG enregistrés aujourd'hui, le core C4
reproduit exactement le runtime conservé lorsqu'il reçoit les mêmes données externes.
Il s'agit d'un **complément versionné**, pas d'une reconstitution des appels externes du
bundle historique incomplet, et pas d'une équivalence universelle sur toutes les requêtes.

Les anciennes fixtures ne sont ni remplacées ni utilisées pour inventer les entrées manquantes.
L'issue, le statut de la PR et sa documentation distante n'ont pas été modifiés ; aucune fusion.
L'adoption de ce complément comme preuve d'acceptation peut donc être examinée séparément.

## Rejouer

Le paquet fournit les sources exactes utilisées, les données JSON et les deux scripts.
Il exclut les secrets, le fichier `.env` et le journal privé. Depuis le dossier extrait,
avec Python 3.12 ou ultérieur :

```bash
PYTHON_DOTENV_DISABLED=1 PYTHONPATH=apps/api/src \
  python3.12 scripts/c4_companion.py replay evidence-v2

python3.12 scripts/check_c4_companion.py
```

Le replay utilise uniquement la bibliothèque standard et les sources core incluses.
Le mode `record` nécessite les dépendances historiques et un accès staging/providers ;
il n'est pas nécessaire pour consulter ou reproduire cette comparaison hors ligne.
